﻿namespace WithoutFlyweightPattern
{
    public class OrderItem
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public ProductType Type { get; set; }
        public double Price { get; set; }
        public string SerialNumber { get; set; }

        public OrderItem(string name, string description, ProductType type, double price, string serialNumber)
        {
            Name = name;
            Description = description;
            Type = type;
            Price = price;
            SerialNumber = serialNumber;
        }
    }

    public enum ProductType
    {
        GamingConsole,
        Desktops,
        Laptop
    }
}