﻿using WithoutFlyweightPattern;
class Program
{
    private static int orderCount = 100000;
    static void Main()
    {
        PSItemFactory pSItemFactory = new PSItemFactory();
        List<Order> orders = new List<Order>();
        //from front dropdown you fetch the PS type
        //for example : it is PS5ConsoleEdition
        //1 lakh order count.....
        var orderPsType = PSSeries.PS5ConsoleEdition;
        for (int i = 0; i < orderCount; i++)
        {
            Order order = new Order();
            OrderItem psItem = pSItemFactory.Create(orderPsType, 1);
            order.Add(psItem);
            orders.Add(order);
        }
        Console.ReadKey();
    }
}