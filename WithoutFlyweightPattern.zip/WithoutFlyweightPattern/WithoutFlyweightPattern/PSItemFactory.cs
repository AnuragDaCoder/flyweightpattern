﻿namespace WithoutFlyweightPattern
{
    public class PSItemFactory 
    {
        public OrderItem Create(PSSeries series, int quantity)
        {
            switch (series)
            {
                case PSSeries.PS5ConsoleEdition:
                    return new OrderItem("PS5 Console Edition",
                        "PS5 Console Edition with a Console free", ProductType.GamingConsole, 54990, quantity);
                case PSSeries.PS5DiscEdition:
                    return new OrderItem("PS5 Disc Edition",
                        "PS5 Disc Edition with a webcam", ProductType.GamingConsole, 54990, quantity);
                case PSSeries.PS4:
                    return new OrderItem("PS4 Console",
                        "PS4 Console old but still the best", ProductType.GamingConsole, 25000, quantity);
                case PSSeries.PS3:
                    return new OrderItem("PS3 Console Edition",
                         "PS3 2006 product", ProductType.GamingConsole, 15000, quantity);
                default:
                    throw new Exception("Unknown Gaming Console");
            }
        }
    }

    public enum PSSeries
    {
        PS5DiscEdition,
        PS5ConsoleEdition,
        PS4,
        PS3
    }
}
